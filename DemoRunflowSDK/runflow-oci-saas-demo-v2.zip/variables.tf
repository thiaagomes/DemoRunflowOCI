variable "compartment_ocid" {
  description = "OCID do compartment onde os recursos serao criados."
  type        = string
}

variable "tenancy_ocid" {
  description = "OCID da tenancy. Opcional; use se a descoberta automatica de AD falhar."
  type        = string
  default     = ""
}

variable "region" {
  description = "Regiao OCI onde a stack sera executada."
  type        = string
  default     = "sa-saopaulo-1"
}

variable "runflow_api_key" {
  description = "Chave da API do Runflow SaaS. Opcional; tambem pode ser configurada depois pela tela web da VM."
  type        = string
  default     = ""
  sensitive   = true
}

variable "grok_api_key" {
  description = "Chave da API xAI/Grok. Opcional; tambem pode ser configurada depois pela tela web da VM."
  type        = string
  default     = ""
  sensitive   = true
}
