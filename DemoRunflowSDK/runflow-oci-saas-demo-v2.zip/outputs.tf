output "public_ip" {
  description = "IP publico da VM."
  value       = oci_core_instance.runflow.public_ip
}

output "app_url" {
  description = "Interface web da demo Runflow em OCI."
  value       = "http://${oci_core_instance.runflow.public_ip}"
}

output "health_url" {
  description = "Endpoint que confirma Runflow SDK, configuracao e servico web."
  value       = "http://${oci_core_instance.runflow.public_ip}/health"
}

output "bootstrap_log" {
  description = "URL do log do bootstrap exposta pelo nginx."
  value       = "http://${oci_core_instance.runflow.public_ip}/logs/bootstrap"
}

output "service_log" {
  description = "URL do log do app web exposta pelo nginx."
  value       = "http://${oci_core_instance.runflow.public_ip}/logs/service"
}
