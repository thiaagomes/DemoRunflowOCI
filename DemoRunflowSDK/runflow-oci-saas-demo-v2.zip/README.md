# Runflow SaaS on Oracle Cloud Infrastructure

Stack Terraform simples para uma demo de hackathon:

- Cria uma VM Ubuntu 22.04 com IP publico.
- Abre HTTP na porta 80.
- Instala Node.js 22, nginx e `@runflow-ai/sdk`.
- Sobe uma interface web em `http://IP_PUBLICO`.
- Aceita `runflow_api_key` e `grok_api_key` no Resource Manager ou depois pela propria tela web.

## Como executar no OCI Resource Manager

1. Crie uma Stack no Resource Manager usando este ZIP.
2. Preencha `compartment_ocid`.
3. Opcionalmente preencha `runflow_api_key` e `grok_api_key`.
4. Rode `Plan`.
5. Rode `Apply`.
6. Abra o output `app_url`.

Se as chaves ficarem vazias no Apply, a demo ainda sobe. Depois acesse `http://IP_PUBLICO`, cole as chaves na secao `Chaves` e clique em `Salvar`.

## Variaveis

| Variavel | Obrigatoria | Descricao |
| --- | --- | --- |
| `compartment_ocid` | Sim | Compartment onde a VM e a rede serao criadas. |
| `runflow_api_key` | Nao | Chave do Runflow SaaS. Pode ser adicionada depois pela UI. |
| `grok_api_key` | Nao | Chave xAI/Grok. Pode ser adicionada depois pela UI. |
| `region` | Nao | Regiao OCI. Padrao: `sa-saopaulo-1`. |
| `tenancy_ocid` | Nao | Use apenas se a descoberta automatica de availability domain falhar. |

## Acesso

A VM foi pensada para demo via navegador, nao via SSH.

- App: `http://IP_PUBLICO`
- Health: `http://IP_PUBLICO/health`
- Logs do bootstrap: `http://IP_PUBLICO/logs/bootstrap`
- Logs do servico: `http://IP_PUBLICO/logs/service`

## Ajustar chaves depois da VM criada

Recomendado para hackathon: abra `http://IP_PUBLICO`, cole as chaves e salve pela UI.

Tambem da para alterar as variaveis no Resource Manager e rodar um novo Apply, mas `cloud-init` roda naturalmente no primeiro boot. Para trocar chaves sem recriar VM, a UI e mais previsivel.

As chaves ficam gravadas na VM em `/opt/runflow/saas-web/config.json`. Use chaves descartaveis/de demo.

## Correcao nesta versao

Esta versao remove o arquivo `cloud-init.yaml.tftpl` e envia o shell script direto no `user_data`, reduzindo o tamanho do metadata para ficar abaixo do limite de 32 KB da OCI.
