output "public_ip" {
  description = "IP publico da VM."
  value       = oci_core_instance.runflow.public_ip
}

output "runflow_url" {
  description = "Interface web funcional usando @runflow-ai/sdk."
  value       = "http://${oci_core_instance.runflow.public_ip}:${local.public_port}"
}

output "status_url" {
  description = "Mesma interface tambem exposta na porta 80."
  value       = "http://${oci_core_instance.runflow.public_ip}"
}

output "health_url" {
  description = "Endpoint que confirma se o SDK carregou."
  value       = "http://${oci_core_instance.runflow.public_ip}:${local.public_port}/health"
}

output "bootstrap_log" {
  description = "URL do log do bootstrap exposta pelo nginx."
  value       = "http://${oci_core_instance.runflow.public_ip}/logs/bootstrap"
}

output "service_log" {
  description = "URL do log do app web exposta pelo nginx."
  value       = "http://${oci_core_instance.runflow.public_ip}/logs/service"
}
