variable "compartment_ocid" {
  description = "OCID do compartment onde os recursos serao criados."
  type        = string
}

variable "tenancy_ocid" {
  description = "OCID da tenancy. Opcional; use se a descoberta automatica de AD falhar."
  type        = string
  default     = ""
}

variable "region" {
  description = "Regiao OCI onde a stack sera executada."
  type        = string
  default     = "sa-saopaulo-1"
}
